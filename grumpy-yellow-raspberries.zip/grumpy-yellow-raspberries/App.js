Snack.expo.dev

import React, { usestate } from 'react;
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react';

const App = () => {
  const [currentSection, setCurrentSection] = usestate('name');

  const resumeData = {
    ImageUrl: require('./myimage.jpg'),
    name: 'Hinzon ken A. Reovoca'
    course: 'Bachelor of Science in Information and Technology',
    education: {
      elementary: 'Abangan Norte Elementary School',
      elementaryYear: '2012'
      highschool: 'Maria Clara HighSchool',
      highschoolYear: '2016'
      college: 'Global Reciprocal College',
      collegeYear: '2024'
    },
    about: 'I am Currently studying Information Technology and soon to be graduate, i spend most of my time in my computer either watching youtube or finishing what has to be done. i sometimes play games and challenge myself in program langauges and application that i never learn before, its tough at first and i lose interest but i keep coming back for it and forcer myself to learn it even more until i finally understand how it works.
    projects:
    {
    contact: {
    mobile: '09668430754',
    email: 'hinzonreovoca@gmail.com',
  },
};

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
       return 'education';
      case 'education':
       return 'projects'; 
      case 'projects':
       return 'contact';
      case 'contact':
       return 'name';
      default:
       return 'name';
    }
  }};
  };

   return {
     <SafeAreaView style={{ flex: 1 }}>
       <ScrollView contentContainerStyle={styles.container}>
         <TouchableOpacity onPress={handlePress} style={style.container}>
           {currentSection === 'name' && {
             <>
               <Image source={resumeData.imageurl} style={style.contentcontainer}>
               <View style={styles.textcontainer}>
                 <Text style={styles.header}>{resumeData.name}</text>
                 <Text style={styles.info}>{resumeData.course}</text>
               </View>
             </>
           }}

           {currentSection === 'education' && (
             <View style={styles.textcontainer}>
              <Text style={styles.header1}> Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                